/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jvuorenm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/02 10:53:04 by jvuorenm          #+#    #+#             */
/*   Updated: 2022/07/02 10:54:16 by jvuorenm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);
int		write_columns(int column, int x);
int		write_lines(int column, int x);

int	write_columns(int column, int x)
{
	while (column < x + 1)
	{
		if (column == 1 || column == x)
		{
			ft_putchar('o');
			if (column == x)
			{
				ft_putchar('\n');
			}
		}
		else
		{
			ft_putchar('-');
		}
		column++;
	}
	return (column);
}

int	write_lines(int column, int x)
{
	while (column < x + 1)
	{
		if (column == 1 || column == x)
		{
			ft_putchar('|');
			if (column == x)
			{
				ft_putchar('\n');
			}
		}
		else
		{
			ft_putchar(' ');
		}
		column++;
	}
	return (column);
}

void	rush(int x, int y)
{
	int	line;
	int	column;

	line = 1;
	column = 1;
	while (line < y + 1)
	{
		if (line == 1 || line == y)
		{
			column = write_columns(column, x);
		}
		else
		{
			column = write_lines(column, x);
		}
		column = 1;
		line++;
	}
}
